/**
 * Project K — a small, extensible Forth kernel in JavaScript.
 *
 * Conceptual target:
 *   - tiny embeddable core
 *   - host/Forth cooperation
 *   - compositional definitions
 *   - context-sensitive input consumption
 *   - resumable cooperative tasks
 *   - extension layer grows the language
 *
 * Usage (Node.js):
 *
 *   const { VM } = require("./projectk.js");
 *   const vm = new VM({ answer: 42 });
 *   vm.dictate(`
 *     code answer
 *       vm.push(answer);
 *     end-code
 *     answer
 *   `);
 *   console.assert(vm.pop() === 42);
 *
 * Only code/end-code are installed initially. JavaScript bodies receive `vm`
 * plus valid-identifier host bindings. All host bindings are also available as
 * `vm.host`.
 *
 * Words are case-sensitive. Compositions capture Word objects, so redefining a
 * name affects later lookups but not compositions already compiled.
 *
 * dictate()/execute() return a Task. Inspect task.status and call resume() after
 * a pause. tick(name) finds a Word by name; last() returns the most recently
 * defined Word.
 *
 * Host words may be generator functions and can:
 *
 *     yield vm.pause();
 *     yield* vm.evaluate(text);
 *     yield* vm.call(word);
 *
 * to preserve their continuation.
 *
 * Tasks are cooperative, in-memory continuations. A VM is not thread-safe.
 * No third-party dependencies.
 */

"use strict";

class ForthError extends Error {
  constructor(message) {
    super(message);
    this.name = "ForthError";
  }
}

class AbortSignal extends Error {}

const PAUSE = Symbol("ProjectK.pause");
const MISSING = Symbol("ProjectK.missing");
const GeneratorFunction = Object.getPrototypeOf(function* () {}).constructor;

class Input {
  /**
   * A consumable source: read a name or an arbitrary region.
   *
   * read() skips whitespace and consumes a whitespace-delimited item.
   * read(until) preserves leading whitespace and consumes the delimiter.
   * `until` may be a literal string or RegExp.
   * Missing delimiters are errors. read() returns null only at end of input.
   */
  constructor(text, position = 0) {
    this.text = String(text);
    this.position = position;
  }

  read(until = undefined) {
    if (until === undefined) {
      const remaining = this.text.slice(this.position);
      const match = /\S+/.exec(remaining);
      if (!match) {
        this.position = this.text.length;
        return null;
      }
      this.position += match.index + match[0].length;
      return match[0];
    }

    let start;
    let end;

    if (typeof until === "string") {
      if (until.length === 0) {
        throw new ForthError("An input boundary cannot be empty");
      }
      start = this.text.indexOf(until, this.position);
      end = start < 0 ? -1 : start + until.length;
    } else if (until instanceof RegExp) {
      const flags = until.flags.replace(/[gy]/g, "");
      const re = new RegExp(until.source, flags);
      const remaining = this.text.slice(this.position);
      const match = re.exec(remaining);
      if (!match) {
        start = end = -1;
      } else {
        start = this.position + match.index;
        end = start + match[0].length;
        if (start === end) {
          throw new ForthError("An input boundary must consume text");
        }
      }
    } else {
      throw new ForthError("An input boundary must be a string or RegExp");
    }

    if (start < 0) {
      throw new ForthError(`Expected input boundary ${String(until)}`);
    }

    const value = this.text.slice(this.position, start);
    this.position = end;
    return value;
  }

  rest() {
    const value = this.text.slice(this.position);
    this.position = this.text.length;
    return value;
  }
}

class Word {
  constructor(name, action, immediate = false, source = "") {
    this.name = name;
    this.action = action;
    this.immediate = immediate;
    this.source = source;
  }

  toString() {
    return `<Word ${this.name}>`;
  }
}

class Value {
  constructor(value) {
    this.value = value;
    Object.freeze(this);
  }
}

class Constant {
  /** Callable-object equivalent used by the optional `constant` defining word. */
  constructor(value) {
    this.value = value;

    // JavaScript objects are not directly callable, so expose an action that
    // preserves the same defining-word idea without special-casing constants
    // inside the VM.
    this.action = vm => vm.push(this.value);
  }

  call(vm) {
    return this.action(vm);
  }

  toString() {
    return `Constant(${String(this.value)})`;
  }
}

class Task {
  /**
   * One execution and its continuation.
   *
   * status: ready | running | paused | done | aborted | failed
   * Work already performed is retained. Cancellation does not undo data or
   * completed definitions.
   */
  constructor(vm, steps) {
    this.vm = vm;
    this._steps = steps;
    this.inputs = [];
    this.status = "ready";
    this.error = null;
  }

  resume() {
    if (this.status !== "ready" && this.status !== "paused") {
      throw new ForthError(`Cannot resume a ${this.status} task`);
    }

    this.status = "running";
    this.vm._active.push(this);

    try {
      const { value, done } = this._steps.next();

      if (done) {
        this.status = "done";
      } else {
        if (value !== PAUSE) {
          throw new ForthError("A word may only yield vm.pause()");
        }
        this.status = "paused";
      }
    } catch (error) {
      if (error instanceof AbortSignal) {
        this.status = "aborted";
        this.vm._discardDefinition();
      } else {
        this.status = "failed";
        this.error = error;
        this.vm._discardDefinition();
        try {
          this._steps.return?.();
        } catch (_) {
          // Preserve the original failure.
        }
        throw error;
      }
    } finally {
      this.vm._active.pop();
    }

    return this;
  }

  cancel() {
    if (this.status === "running") {
      throw new ForthError("Use vm.abort() inside a running task");
    }

    if (this.status === "ready" || this.status === "paused") {
      this.vm._active.push(this);
      try {
        this._steps.return?.();
        this.vm._discardDefinition(this);
        this.status = "aborted";
      } finally {
        this.vm._active.pop();
      }
    }

    return this;
  }
}

class VM {
  /** Persistent working data and definitions, independent of other VMs. */
  constructor(host = {}) {
    this.stack = [];
    this.words = new Map();
    this.host = { ...host };
    this._active = [];
    this._definition = null;
    this._last = null;

    this.define("code", vm => vm._code());
    this.define("end-code", vm => vm._unexpectedEnd());
  }

  get input() {
    if (this._active.length === 0) {
      throw new ForthError("No active input");
    }
    const task = this._active[this._active.length - 1];
    if (task.inputs.length === 0) {
      throw new ForthError("No active input");
    }
    return task.inputs[task.inputs.length - 1];
  }

  get compiling() {
    return this._definition !== null;
  }

  push(...values) {
    this.stack.push(...values);
    return this;
  }

  pop() {
    if (this.stack.length === 0) {
      throw new ForthError("Data stack is empty");
    }
    return this.stack.pop();
  }

  peek(depth = 0) {
    if (!Number.isInteger(depth) || depth < 0 || depth >= this.stack.length) {
      throw new ForthError("Invalid data stack depth");
    }
    return this.stack[this.stack.length - 1 - depth];
  }

  define(name, action, { immediate = false, source = "" } = {}) {
    if (
      typeof name !== "string" ||
      name.length === 0 ||
      /\s/.test(name)
    ) {
      throw new ForthError("A word needs a nonempty name without whitespace");
    }

    const isComposition = Array.isArray(action);
    const isCallable =
      typeof action === "function" ||
      (action && typeof action.call === "function");

    if (!isCallable && !isComposition) {
      throw new ForthError("A definition needs a host function or composition");
    }

    const stableAction = isComposition
      ? Object.freeze([...action])
      : action;

    const word = new Word(name, stableAction, immediate, source);
    this.words.set(name, word);
    this._last = word;
    return word;
  }

  tick(name) {
    /** Find a Word by name, or return null when it is absent. */
    return this.words.get(name) ?? null;
  }

  last() {
    /** Return the most recently defined Word, or null if none exists. */
    return this._last;
  }

  _requireWord(name) {
    const word = this.tick(name);
    if (word === null) {
      throw new ForthError(`Unknown word: ${name}`);
    }
    return word;
  }

  begin(name) {
    if (this.compiling) {
      throw new ForthError("A definition is already being built");
    }
    if (
      typeof name !== "string" ||
      name.length === 0 ||
      /\s/.test(name)
    ) {
      throw new ForthError("Expected a definition name");
    }

    const owner =
      this._active.length > 0
        ? this._active[this._active.length - 1]
        : null;

    this._definition = { owner, name, body: [] };
    return this;
  }

  emit(operation) {
    if (!this.compiling) {
      throw new ForthError("No definition is being built");
    }

    if (typeof operation === "string") {
      operation = this._requireWord(operation);
    }

    const okay =
      operation instanceof Word ||
      operation instanceof Value ||
      typeof operation === "function" ||
      (operation && typeof operation.call === "function");

    if (!okay) {
      throw new ForthError("Expected an operation; use literal() for data");
    }

    this._definition.body.push(operation);
    return this;
  }

  literal(value) {
    return this.emit(new Value(value));
  }

  finish() {
    if (!this.compiling) {
      throw new ForthError("No definition is being built");
    }

    const { name, body } = this._definition;
    const word = this.define(name, body);
    this._definition = null;
    return word;
  }

  _discardDefinition(owner = MISSING) {
    if (
      this.compiling &&
      (owner === MISSING || this._definition.owner === owner)
    ) {
      this._definition = null;
    }
  }

  static pause() {
    return PAUSE;
  }

  pause() {
    return PAUSE;
  }

  static abort() {
    throw new AbortSignal();
  }

  abort() {
    throw new AbortSignal();
  }

  dictate(text) {
    return new Task(this, this.evaluate(text)).resume();
  }

  execute(operation) {
    return new Task(this, this.call(operation)).resume();
  }

  *call(operation) {
    /** Generator interface for calls that may yield back to the host. */
    if (typeof operation === "string") {
      operation = this._requireWord(operation);
    }

    if (operation instanceof Value) {
      this.push(operation.value);
      return;
    }

    const action = operation instanceof Word ? operation.action : operation;

    if (Array.isArray(action)) {
      for (const step of action) {
        yield* this.call(step);
      }
      return;
    }

    let result;

    try {
      if (typeof action === "function") {
        result = action(this);
      } else if (action && typeof action.call === "function") {
        result = action.call(this);
      } else {
        throw new ForthError(`Cannot execute ${String(operation)}`);
      }

      if (result && typeof result.next === "function") {
        yield* result;
      } else if (result === PAUSE) {
        yield PAUSE;
      }
    } catch (error) {
      if (error instanceof ForthError || error instanceof AbortSignal) {
        throw error;
      }

      const name =
        operation instanceof Word ? operation.name : String(action);
      throw new ForthError(`${name}: ${error?.message ?? String(error)}`);
    }
  }

  *evaluate(text) {
    /** Interpret source inside the current task, preserving its context. */
    const source = new Input(text);

    if (this._active.length === 0) {
      throw new ForthError("evaluate() needs an active task");
    }

    const task = this._active[this._active.length - 1];
    task.inputs.push(source);

    try {
      for (;;) {
        const item = source.read();
        if (item === null) break;

        const word = this.words.get(item);

        if (word !== undefined) {
          if (this.compiling && !word.immediate) {
            this.emit(word);
          } else {
            yield* this.call(word);
          }
        } else {
          const value = VM._number(item);
          if (this.compiling) {
            this.literal(value);
          } else {
            this.push(value);
          }
        }
      }
    } finally {
      task.inputs.pop();
    }
  }

  static _number(text) {
    // Decimal integer first. Preserve exactness outside Number's safe range.
    if (/^[+-]?\d+$/.test(text)) {
      try {
        const big = BigInt(text);
        const max = BigInt(Number.MAX_SAFE_INTEGER);
        const min = BigInt(Number.MIN_SAFE_INTEGER);
        return big >= min && big <= max ? Number(big) : big;
      } catch (_) {
        // Fall through to the generic numeric forms below.
      }
    }

    // JavaScript-style 0x / 0o / 0b integers, with optional sign.
    const based = /^([+-]?)(0[xX][0-9a-fA-F]+|0[oO][0-7]+|0[bB][01]+)$/.exec(text);
    if (based) {
      const sign = based[1] === "-" ? -1n : 1n;
      try {
        const big = sign * BigInt(based[2]);
        const max = BigInt(Number.MAX_SAFE_INTEGER);
        const min = BigInt(Number.MIN_SAFE_INTEGER);
        return big >= min && big <= max ? Number(big) : big;
      } catch (_) {
        // Fall through.
      }
    }

    // Floating point, including exponent notation.
    if (
      /^[+-]?(?:(?:\d+\.\d*|\.\d+|\d+\.\d+)(?:[eE][+-]?\d+)?|\d+[eE][+-]?\d+)$/.test(text)
    ) {
      const value = Number(text);
      if (Number.isFinite(value)) return value;
    }

    throw new ForthError(`Unknown input: ${text}`);
  }

  _code() {
    if (this.compiling) {
      throw new ForthError(
        "Host definitions cannot nest inside a composition"
      );
    }

    const name = this.input.read();
    if (name === null) {
      throw new ForthError("Expected a name after code");
    }

    const body = this._readCode();

    const bindingNames = Object.keys(this.host).filter(VM._validBindingName);
    const bindingValues = bindingNames.map(name => this.host[name]);

    let operation;
    try {
      const compiled = new GeneratorFunction(
        "vm",
        ...bindingNames,
        `${body}\n//# sourceURL=ProjectK:${name}`
      );

      operation = function* (vm) {
        yield* compiled(vm, ...bindingValues);
      };
    } catch (error) {
      throw new ForthError(
        `Cannot define ${name}: ${error?.message ?? String(error)}`
      );
    }

    this.define(name, operation, { source: body });
  }

  static _validBindingName(name) {
    // Exclude names that are syntactically unsafe as function parameters.
    if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(name)) return false;
    try {
      // Generator parameters have a few context-sensitive reserved names.
      new GeneratorFunction(name, "yield;");
      return true;
    } catch (_) {
      return false;
    }
  }

  _readCode() {
    /**
     * Find end-code on a line of its own while ignoring occurrences inside
     * strings, template literals, and comments.
     *
     * This is intentionally a tiny lexical scanner, not a JavaScript parser.
     * It only decides whether an end-code line belongs to host source text.
     */
    const source = this.input;
    const start = source.position;
    const remaining = source.text.slice(start);

    let state = "normal"; // normal | single | double | template | block
    let escaped = false;
    let offset = 0;

    const lines = remaining.match(/[^\n]*(?:\n|$)/g) ?? [];

    for (const line of lines) {
      if (line.length === 0) continue;

      const withoutNewline = line.replace(/\r?\n$/, "");

      if (state === "normal" && /^\s*end-code\s*$/.test(withoutNewline)) {
        const body = remaining.slice(0, offset);
        source.position = start + offset + line.length;
        return body;
      }

      let lineComment = false;

      for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        const next = line[i + 1];

        if (lineComment) break;

        if (state === "block") {
          if (ch === "*" && next === "/") {
            state = "normal";
            i++;
          }
          continue;
        }

        if (state === "single") {
          if (escaped) {
            escaped = false;
          } else if (ch === "\\") {
            escaped = true;
          } else if (ch === "'") {
            state = "normal";
          }
          continue;
        }

        if (state === "double") {
          if (escaped) {
            escaped = false;
          } else if (ch === "\\") {
            escaped = true;
          } else if (ch === '"') {
            state = "normal";
          }
          continue;
        }

        if (state === "template") {
          if (escaped) {
            escaped = false;
          } else if (ch === "\\") {
            escaped = true;
          } else if (ch === "`") {
            state = "normal";
          }
          // `${...}` deliberately remains inside template state. For the only
          // purpose of this scanner, this avoids falsely terminating on text
          // that is lexically part of one template literal.
          continue;
        }

        // normal
        if (ch === "/" && next === "/") {
          lineComment = true;
          break;
        }
        if (ch === "/" && next === "*") {
          state = "block";
          i++;
          continue;
        }
        if (ch === "'") {
          state = "single";
          escaped = false;
          continue;
        }
        if (ch === '"') {
          state = "double";
          escaped = false;
          continue;
        }
        if (ch === "`") {
          state = "template";
          escaped = false;
        }
      }

      // Ordinary quoted strings cannot legally cross an unescaped newline.
      // Leave syntax errors to JavaScript compilation, but prevent a bad line
      // from hiding all later end-code markers forever.
      if (state === "single" || state === "double") {
        const trimmed = line.replace(/\r?\n$/, "");
        if (!trimmed.endsWith("\\")) {
          state = "normal";
          escaped = false;
        }
      }

      offset += line.length;
    }

    throw new ForthError("Expected end-code on a line of its own");
  }

  _unexpectedEnd() {
    throw new ForthError("end-code has no matching code definition");
  }
}


// Example extension layer: none of these words are hardwired into VM.
const DEMO = String.raw`
code dup
  vm.push(vm.peek());
end-code

code *
  const b = vm.pop(), a = vm.pop();
  vm.push(a * b);
end-code

code .
  console.log(vm.pop());
end-code

code :
  vm.begin(vm.input.read());
end-code

code immediate
  const word = vm.last();
  if (word === null) {
    throw new ForthError("immediate needs a previous definition");
  }
  word.immediate = true;
end-code

code ;
  vm.finish();
end-code
immediate

code constant
  const name = vm.input.read();
  if (name === null) {
    throw new ForthError("constant expects a name");
  }
  vm.define(name, new Constant(vm.pop()));
end-code

code text
  const value = vm.input.read("|").replace(/^\s+/, "");
  if (vm.compiling) {
    vm.literal(value);
  } else {
    vm.push(value);
  }
end-code
immediate

code pause
  yield vm.pause();
end-code

: square dup * ;
: greeting text Hello from Project K!| . ;
: interrupted 3 square . pause 4 square . ;
10 constant ten

greeting ten 2 * . 12 square . interrupted
`;


// CommonJS export for Node.js. The classes themselves are otherwise ordinary
// JavaScript and can be embedded directly in another host environment.
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    VM,
    Task,
    Input,
    Word,
    Constant,
    ForthError,
    DEMO,
  };
}


// Run the demonstration when invoked directly with Node.js.
if (
  typeof require !== "undefined" &&
  typeof module !== "undefined" &&
  require.main === module
) {
  const machine = new VM({ Constant, ForthError });
  console.log("Initial words:", [...machine.words.keys()].join(", "));

  const work = machine.dictate(DEMO);
  console.log("Task:", work.status, "— returning control to the host");

  work.resume();
  console.log("Task:", work.status);
}
